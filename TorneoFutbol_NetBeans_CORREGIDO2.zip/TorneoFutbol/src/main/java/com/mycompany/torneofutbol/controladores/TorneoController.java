package com.mycompany.torneofutbol.controladores;

import java.util.*;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.TextFormatter;

public class TorneoController {

    @FXML private TabPane pestanas;
    @FXML private Button btnGuardar;
    @FXML private Button btnEditar;
    @FXML private Button btnEliminar;
    @FXML private Label lblMensaje;

    @FXML private TextField txtAdministradorUsuario;
    @FXML private Label lblAdministradorUsuarioError;
    @FXML private TextField txtAdministradorNombre;
    @FXML private Label lblAdministradorNombreError;
    @FXML private TextField txtAdministradorApellidos;
    @FXML private Label lblAdministradorApellidosError;
    @FXML private TextField txtAdministradorCorreo;
    @FXML private Label lblAdministradorCorreoError;
    @FXML private ListView<String> listaAdministrador;
    @FXML private TextField txtEquipoNombre;
    @FXML private Label lblEquipoNombreError;
    @FXML private TextField txtEquipoCiudad;
    @FXML private Label lblEquipoCiudadError;
    @FXML private TextField txtEquipoEntrenador;
    @FXML private Label lblEquipoEntrenadorError;
    @FXML private ListView<String> listaEquipo;
    @FXML private TextField txtJugadorNombre;
    @FXML private Label lblJugadorNombreError;
    @FXML private TextField txtJugadorApellidos;
    @FXML private Label lblJugadorApellidosError;
    @FXML private TextField txtJugadorNumero;
    @FXML private Label lblJugadorNumeroError;
    @FXML private TextField txtJugadorPosicion;
    @FXML private Label lblJugadorPosicionError;
    @FXML private ListView<String> listaJugador;
    @FXML private TextField txtPartidoJornada;
    @FXML private Label lblPartidoJornadaError;
    @FXML private TextField txtPartidoFecha;
    @FXML private Label lblPartidoFechaError;
    @FXML private TextField txtPartidoLocal;
    @FXML private Label lblPartidoLocalError;
    @FXML private TextField txtPartidoVisitante;
    @FXML private Label lblPartidoVisitanteError;
    @FXML private ListView<String> listaPartido;
    @FXML private TextField txtResultadoPartido;
    @FXML private Label lblResultadoPartidoError;
    @FXML private TextField txtResultadoGolesLocal;
    @FXML private Label lblResultadoGolesLocalError;
    @FXML private TextField txtResultadoGolesVisitante;
    @FXML private Label lblResultadoGolesVisitanteError;
    @FXML private ListView<String> listaResultado;
    @FXML private TextField txtPosicionEquipo;
    @FXML private Label lblPosicionEquipoError;
    @FXML private TextField txtPosicionPuntos;
    @FXML private Label lblPosicionPuntosError;
    @FXML private TextField txtPosicionJugados;
    @FXML private Label lblPosicionJugadosError;
    @FXML private TextField txtPosicionDiferencia;
    @FXML private Label lblPosicionDiferenciaError;
    @FXML private ListView<String> listaPosicion;

    private final Map<String, TextField> campos = new LinkedHashMap<>();
    private final Map<String, Label> errores = new LinkedHashMap<>();
    private final Map<String, ListView<String>> listas = new LinkedHashMap<>();
    private final Map<String, Integer> consecutivos = new HashMap<>();

    @FXML
    private void initialize() {
        listas.put("Administrador", listaAdministrador);
        listas.put("Equipo", listaEquipo);
        listas.put("Jugador", listaJugador);
        listas.put("Partido", listaPartido);
        listas.put("Resultado", listaResultado);
        listas.put("Posicion", listaPosicion);
        campos.put("Administrador:usuario", txtAdministradorUsuario);
        errores.put("Administrador:usuario", lblAdministradorUsuarioError);
        campos.put("Administrador:nombre", txtAdministradorNombre);
        errores.put("Administrador:nombre", lblAdministradorNombreError);
        campos.put("Administrador:apellidos", txtAdministradorApellidos);
        errores.put("Administrador:apellidos", lblAdministradorApellidosError);
        campos.put("Administrador:correo", txtAdministradorCorreo);
        errores.put("Administrador:correo", lblAdministradorCorreoError);
        campos.put("Equipo:nombre", txtEquipoNombre);
        errores.put("Equipo:nombre", lblEquipoNombreError);
        campos.put("Equipo:ciudad", txtEquipoCiudad);
        errores.put("Equipo:ciudad", lblEquipoCiudadError);
        campos.put("Equipo:entrenador", txtEquipoEntrenador);
        errores.put("Equipo:entrenador", lblEquipoEntrenadorError);
        campos.put("Jugador:nombre", txtJugadorNombre);
        errores.put("Jugador:nombre", lblJugadorNombreError);
        campos.put("Jugador:apellidos", txtJugadorApellidos);
        errores.put("Jugador:apellidos", lblJugadorApellidosError);
        campos.put("Jugador:numero", txtJugadorNumero);
        errores.put("Jugador:numero", lblJugadorNumeroError);
        campos.put("Jugador:posicion", txtJugadorPosicion);
        errores.put("Jugador:posicion", lblJugadorPosicionError);
        campos.put("Partido:jornada", txtPartidoJornada);
        errores.put("Partido:jornada", lblPartidoJornadaError);
        campos.put("Partido:fecha", txtPartidoFecha);
        errores.put("Partido:fecha", lblPartidoFechaError);
        campos.put("Partido:local", txtPartidoLocal);
        errores.put("Partido:local", lblPartidoLocalError);
        campos.put("Partido:visitante", txtPartidoVisitante);
        errores.put("Partido:visitante", lblPartidoVisitanteError);
        campos.put("Resultado:partido", txtResultadoPartido);
        errores.put("Resultado:partido", lblResultadoPartidoError);
        campos.put("Resultado:golesLocal", txtResultadoGolesLocal);
        errores.put("Resultado:golesLocal", lblResultadoGolesLocalError);
        campos.put("Resultado:golesVisitante", txtResultadoGolesVisitante);
        errores.put("Resultado:golesVisitante", lblResultadoGolesVisitanteError);
        campos.put("Posicion:equipo", txtPosicionEquipo);
        errores.put("Posicion:equipo", lblPosicionEquipoError);
        campos.put("Posicion:puntos", txtPosicionPuntos);
        errores.put("Posicion:puntos", lblPosicionPuntosError);
        campos.put("Posicion:jugados", txtPosicionJugados);
        errores.put("Posicion:jugados", lblPosicionJugadosError);
        campos.put("Posicion:diferencia", txtPosicionDiferencia);
        errores.put("Posicion:diferencia", lblPosicionDiferenciaError);
        for (String entidad : listas.keySet()) {
            consecutivos.put(entidad, 1);
        }

        for (Map.Entry<String, TextField> entrada : campos.entrySet()) {
            String clave = entrada.getKey();
            TextField campo = entrada.getValue();

            if (esNumerico(clave)) {
                campo.setTextFormatter(new TextFormatter<String>(cambio -> {
                    String texto = cambio.getControlNewText();
                    return texto.matches("\\d*") ? cambio : null;
                }));
            } else {
                campo.setTextFormatter(new TextFormatter<String>(cambio -> {
                    String texto = cambio.getControlNewText();
                    return texto.matches("[\\p{L}0-9 .,'@_\\-]*") ? cambio : null;
                }));
            }

            campo.textProperty().addListener((obs, anterior, actual) -> {
                if (entidadActual().equals(entidadDe(clave))) {
                    actualizarFormulario();
                }
            });
        }

        for (Map.Entry<String, ListView<String>> entrada : listas.entrySet()) {
            entrada.getValue().getSelectionModel().selectedItemProperty()
                    .addListener((obs, anterior, actual) -> {
                        if (entidadActual().equals(entrada.getKey())) {
                            boolean seleccionado = actual != null;
                            btnEditar.setDisable(!seleccionado);
                            btnEliminar.setDisable(!seleccionado);
                        }
                    });
        }

        pestanas.getSelectionModel().selectedItemProperty().addListener(
                (obs, anterior, actual) -> {
                    limpiarCamposActuales();
                    btnGuardar.setDisable(true);
                    btnEditar.setDisable(true);
                    btnEliminar.setDisable(true);
                    lblMensaje.setText("Gestión de " + entidadActual() + ".");
                });
    }

    private String entidadActual() {
        String nombre = pestanas.getSelectionModel().getSelectedItem().getText();
        return nombre.equals("Posiciones") ? "Posicion" : nombre;
    }

    private String entidadDe(String clave) {
        return clave.substring(0, clave.indexOf(":"));
    }

    private boolean esNumerico(String clave) {
        return Arrays.asList(
                "Jugador:numero",
                "Partido:jornada",
                "Resultado:golesLocal",
                "Resultado:golesVisitante",
                "Posicion:puntos",
                "Posicion:jugados",
                "Posicion:diferencia"
        ).contains(clave);
    }

    private List<String> clavesActuales() {
        String entidad = entidadActual();
        List<String> resultado = new ArrayList<>();
        for (String clave : campos.keySet()) {
            if (entidadDe(clave).equals(entidad)) resultado.add(clave);
        }
        return resultado;
    }

    private boolean validarCampo(String clave) {
        TextField campo = campos.get(clave);
        Label error = errores.get(clave);
        String valor = campo.getText().trim();

        if (valor.isEmpty()) {
            error.setText("Este campo es obligatorio");
            return false;
        }

        if (esNumerico(clave) && !valor.matches("\\d+")) {
            error.setText("Ingresa un número entero válido");
            return false;
        }

        if (clave.endsWith(":correo")
                && !valor.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")) {
            error.setText("Ingresa un correo válido");
            return false;
        }

        if (clave.endsWith(":fecha")
                && !valor.matches("^\\d{2}/\\d{2}/\\d{4}$")) {
            error.setText("Formato esperado: dd/mm/aaaa");
            return false;
        }

        error.setText("");
        return true;
    }

    private boolean formularioValido() {
        boolean valido = true;
        for (String clave : clavesActuales()) {
            if (!validarCampo(clave)) valido = false;
        }
        return valido;
    }

    private void actualizarFormulario() {
        boolean valido = formularioValido();
        btnGuardar.setDisable(!valido);
    }

    @FXML
    private void nuevo() {
        limpiarCamposActuales();
        btnGuardar.setDisable(true);
        btnEditar.setDisable(true);
        btnEliminar.setDisable(true);
        listas.get(entidadActual()).getSelectionModel().clearSelection();
        lblMensaje.setText("Nuevo registro: captura los datos.");
    }

    @FXML
    private void validar() {
        if (formularioValido()) {
            Alert alerta = new Alert(Alert.AlertType.INFORMATION);
            alerta.setTitle("Validación correcta");
            alerta.setHeaderText("Formulario válido");
            alerta.setContentText("Todos los datos cumplen con las validaciones.");
            alerta.showAndWait();
            lblMensaje.setText("Validación completada correctamente.");
        } else {
            lblMensaje.setText("Revisa los campos que contienen errores.");
        }
    }

    @FXML
    private void guardar() {
        if (!formularioValido()) {
            btnGuardar.setDisable(true);
            return;
        }

        String entidad = entidadActual();
        StringBuilder registro = new StringBuilder();
        int id = consecutivos.get(entidad);
        consecutivos.put(entidad, id + 1);
        registro.append(id).append(" | ");
        List<String> valores = new ArrayList<>();
        for (String clave : clavesActuales()) {
            valores.add(campos.get(clave).getText().trim());
        }
        registro.append(String.join(" | ", valores));
        listas.get(entidad).getItems().add(registro.toString());

        lblMensaje.setText("Registro agregado a la lista (solo durante esta ejecución).");
        limpiarCamposActuales();
        btnGuardar.setDisable(true);
    }

    @FXML
    private void editar() {
        if (listas.get(entidadActual()).getSelectionModel().getSelectedItem() != null) {
            mostrarAviso("Editar", "Acción demostrativa: no se modificará información.");
        }
    }

    @FXML
    private void eliminar() {
        if (listas.get(entidadActual()).getSelectionModel().getSelectedItem() != null) {
            mostrarAviso("Eliminar", "Acción demostrativa: no se eliminará información.");
        }
    }

    private void mostrarAviso(String titulo, String mensaje) {
        Alert alerta = new Alert(Alert.AlertType.INFORMATION);
        alerta.setTitle(titulo);
        alerta.setHeaderText("Registro seleccionado");
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }

    @FXML
    private void limpiar() {
        limpiarCamposActuales();
        listas.get(entidadActual()).getSelectionModel().clearSelection();
        btnGuardar.setDisable(true);
        btnEditar.setDisable(true);
        btnEliminar.setDisable(true);
        lblMensaje.setText("Formulario limpio.");
    }

    private void limpiarCamposActuales() {
        for (String clave : clavesActuales()) {
            campos.get(clave).clear();
            errores.get(clave).setText("");
        }
    }
}
